---
title: GitHub Clone
---

![GitHub Clone]({{ site.github.url }}/assets/img/work/proj-7/img-1.jpg)

Retrieved data via the GitHub API formatted into HTML through the use of the promise pattern. New user data can be retrieved by searching an individual's GitHub username. Source code available on [GitHub](https://github.com/BuckyMaler/github-clone){:target="_blank"}.

![Search by Username]({{ site.github.url }}/assets/img/work/proj-7/img-2.jpg)

Built With: HTML5, Sass, JavaScript, jQuery

<a href="http://buckymaler.com/github-clone" class="work-btn" target="_blank">View Work</a>
